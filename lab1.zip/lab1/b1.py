name = str(input('Input your name: '))
print(f'Welcome, {name}!')