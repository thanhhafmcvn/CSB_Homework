from turtle import *
shape('turtle')
for i in range(3):
    forward(200)
    left(120)
forward(100)
left(90)
mainloop()