print('Name \t \t \t \t : \t \t \t Michael')
print('Birthdate \t \t \t : \t \t \t 01/01/2001')