year = str(input('What year is it? \n'))
if len(year) == 4:
    print('\t\t           . : .')
    print("\t\t         '.  :  .'")
    print("HAPPY NEW YEAR \t\t.  '.:.'  .")
    print(f"!!! {year} !!! \t        .  .':'.  .")
    print("\t\t         .'  :  ' .")
    print("\t\t           ' : '")



