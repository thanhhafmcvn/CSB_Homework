from turtle import *
radius = float(input("Input circle's radius: "))
circle(radius)
mainloop()