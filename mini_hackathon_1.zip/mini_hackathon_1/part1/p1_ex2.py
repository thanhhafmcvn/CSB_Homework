userInput = str(input('Your input: '))
print(f'Capitalized: {userInput.upper()}')