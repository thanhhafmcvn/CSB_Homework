firstName = str(input('First name: '))
lastName = str(input('Last name: '))
print(f'Your full name is {firstName} {lastName}')