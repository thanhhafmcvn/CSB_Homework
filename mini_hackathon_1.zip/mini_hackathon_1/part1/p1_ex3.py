number = float(input("Input a number: "))
print(f"Squared input: {number**2}")
