number = int(input('Input a number: '))
if number%2 == 0:
    print('This number is even')
else:
    print('This number is not even')