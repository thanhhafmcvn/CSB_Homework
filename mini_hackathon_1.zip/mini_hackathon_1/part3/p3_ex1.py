number = float(input('Input a number: '))
if number > 13:
    print('This number is larger than 13')
elif number == 13:
    print('This number is equal to 13')
else:
    print('This number is not larger than 13')