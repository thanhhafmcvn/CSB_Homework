num1 = 2
num2 = 3
op = "+"
result = 5
print(eval(str(f'{num1} {op} {num2}')) == result)