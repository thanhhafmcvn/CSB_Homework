number = int(input('Input a number: '))
for i in range(number+1):
    print(i, end=" ")