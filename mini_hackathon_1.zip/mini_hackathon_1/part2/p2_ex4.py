number = int(input('Input a number: '))
for i in range(1, number+1, 2):
    print(i, end=" ")