for i in range(3, 13):
    print(i, end=" ")