number = int(input('Input number: '))
sum = 0
if number > 0:
    for i in str(number):
        sum = sum + int(i)
print(sum)