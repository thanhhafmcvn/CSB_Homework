time = int(input('Input number: '))
for i in range(1, time+1):
    print('#'*i)