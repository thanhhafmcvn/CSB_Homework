from turtle import *

r = 10
for i in range(19):
    circle(r, 180)
    r += 10

mainloop()
