n = float(input("Input a positive number: "))
while n < 0 or n % 1 != 0:
    n = float(input("Input a positive number: "))
print(f"Thank you. {n}")

