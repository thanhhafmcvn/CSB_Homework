num = float(input('Enter a number: '))
if num%1 == 0:
    print(f'{num} is an integer number')
else:
    print(f'{num} is not an integer number')