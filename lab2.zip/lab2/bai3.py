account_name = input('Account name: ')
domain_name = input('Domain name: ')
print(f'Full email: {account_name}@{domain_name}')