from math import *
edge = float(input('Length of edge: '))
diagonal_line = sqrt(2*pow(edge, 2))
print(f'Length of diagonal line: {diagonal_line}')