pi = 3.1416
r = float(input('Radius: '))
perimeter = 2*pi*r
area = pi*pow(r,2)
print(f'Perimeter: {perimeter}')
print(f'Area: {area}')
