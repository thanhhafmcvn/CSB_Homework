from math import *
a = 4
b = 5
c = 0
def pythagoras_theorem():
    c = sqrt((pow(float(a),2) + pow(float(b),2)))
    print(c)
pythagoras_theorem()