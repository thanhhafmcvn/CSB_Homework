inp = input()
print(type(inp))
#input: 
#output: <class 'str'>