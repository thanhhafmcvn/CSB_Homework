num = 20
num += input()
print(num)
# TypeError: unsupported operand type(s) for +=: 'int' and 'str'
# D. Chương trình lỗi