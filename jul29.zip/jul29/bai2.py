# Convert float to int 
# int() function
num = 3.0
print(int(num))