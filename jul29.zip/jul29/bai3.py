rate = 12%
print(rate)
# SyntaxError: invalid synta
# rate = 12% is incorrect