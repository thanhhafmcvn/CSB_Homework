number_list = [5, 1, 8, 92, 7, 30]
[print(i, end=" ") for i in number_list if i%2==0]
