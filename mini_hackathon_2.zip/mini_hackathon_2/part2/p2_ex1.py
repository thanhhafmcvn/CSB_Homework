color_list = ["blue",  "teal", "green"]
print(color_list[int(input('\nInput position:'))-1])
