color_list = ["blue", "teal", "green"]
[print(i, end=", ") for i in color_list]