color_list = ["blue",  "teal", "green"]
print("Color list: ", *color_list)
color_list.append(str(input('\nInput a new color: ')))
print(*color_list)
