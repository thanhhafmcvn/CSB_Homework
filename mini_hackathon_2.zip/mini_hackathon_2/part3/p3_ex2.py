number_list = [5, 1, 8, 92, -1, 30]
print(f'Sum of numbers in list {sum(number_list)}')